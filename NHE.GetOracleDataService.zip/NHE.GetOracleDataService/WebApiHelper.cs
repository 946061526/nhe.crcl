﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.SelfHost;
using System.Configuration;
using NLog;

namespace NHE.GetOracleDataService
{
    public class WebApiHelper
    {
        private Logger _logger = LogManager.GetCurrentClassLogger();

        HttpSelfHostConfiguration config = null;
        HttpSelfHostServer server = null;

        /// <summary>
        /// 注册WebHost
        /// </summary>
        public void RegisterWebApiHost(string host)
        {
            //var host = "http://localhost:8181";
            try
            {
                config = new HttpSelfHostConfiguration(host);
                config.Routes.MapHttpRoute("API Default", "api/{controller}/{id}", new { id = RouteParameter.Optional });
                server = new HttpSelfHostServer(config);
                server.OpenAsync().Wait();

                _logger.Info($"已注册WebHost:{host}");
            }
            catch (Exception ex)
            {
                _logger.Info($"WebHost'{host}'注册失败：{ex.Message}");
            }
        }
    }
}
