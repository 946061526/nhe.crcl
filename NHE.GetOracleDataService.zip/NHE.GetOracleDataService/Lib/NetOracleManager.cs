﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;

namespace NHE.GetOracleDataService
{
    public class NetOracleManager
    {

        /// <summary>
        /// 获取数据库连接
        /// </summary>
        /// <returns></returns>
        public static OracleConnection GetConn(string connStr)
        {
            OracleConnection conn = new OracleConnection(connStr);
            conn.Open();
            return conn;
        }

        /// <summary>
        /// 关闭连接
        /// </summary>
        /// <param name="conn"></param>
        public static void CloseConn(OracleConnection conn)
        {
            if (conn == null) { return; }
            try
            {
                if (conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                conn.Dispose();
            }
        }

        /// <summary>
        /// 查询结果集，返回DataTable
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="conn"></param>
        /// <returns></returns>
        public static DataTable GetDataTable(string sql, OracleConnection conn)
        {
            DataTable ds = new DataTable();
            OracleDataAdapter da = new OracleDataAdapter(sql, conn);
            da.Fill(ds);
            return ds;

        }

        /// <summary>
        /// 执行sql语句，返回受影响行数
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="conn"></param>
        /// <returns></returns>
        public static int ExecuteNonQuery(string sql, OracleConnection conn)
        {
            //创建操作命令对象 
            OracleCommand cmd = new OracleCommand(sql, conn);
            int val = cmd.ExecuteNonQuery();
            conn.Close();
            cmd.Dispose();
            return val;
        }
    }
}
