﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using System.Xml;

namespace NHE.GetOracleDataService
{
    /// <summary>
    /// APP设置
    /// </summary>
    public class AppSetting
    {
        /// <summary>
        /// oracle连接串
        /// </summary>
        public string OracleConn { get; set; }
        /// <summary>
        /// 查询SQL语句
        /// </summary>
        public string Sql { get; set; }
        /// <summary>
        /// 修改状态oracle连接串
        /// </summary>
        public string OracleConnUpdateStatus { get; set; }
        /// <summary>
        /// 修改状态SQL语句
        /// </summary>
        public string SqlUpdateStatus { get; set; }
        /// <summary>
        /// 取最近多少分钟内数据（单位：分钟）
        /// </summary>
        public int DataStartTime { get; set; }
        /// <summary>
        /// 服务运行间隔时间(单位：秒)
        /// </summary>
        public int Interval { get; set; }
        /// <summary>
        /// 保存数据接口地址
        /// </summary>
        public string SaveUrl { get; set; }
        /// <summary>
        /// 对外提供webapi服务器
        /// </summary>
        public string WebApiHost { get; set; }


        /// <summary>
        /// 初始化配置文件
        /// </summary>
        public AppSetting()
        {
            try
            {
                var url = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Config", "AppSetting.xml");
                var xml = new XmlDocument();
                xml.Load(url);

                OracleConn = xml.SelectSingleNode("HE/OracleConn").InnerText.Replace("\r", " ").Replace("\n", " ").Replace("\t", " ");
                Sql = xml.SelectSingleNode("HE/Sql").InnerText.Replace("\r", " ").Replace("\n", " ").Replace("\t", " ");
                
                OracleConnUpdateStatus = xml.SelectSingleNode("HE/OracleConnUpdateStatus").InnerText.Replace("\r", " ").Replace("\n", " ").Replace("\t", " ");
                SqlUpdateStatus = xml.SelectSingleNode("HE/SqlUpdateStatus").InnerText.Replace("\r", " ").Replace("\r", " ").Replace("\t", " ");

                int h = 10;
                int.TryParse(xml.SelectSingleNode("HE/DataStartTime").InnerText, out h);
                DataStartTime = h;

                h = 600;
                int.TryParse(xml.SelectSingleNode("HE/Interval").InnerText, out h);
                Interval = h;

                SaveUrl = xml.SelectSingleNode("HE/SaveUrl").InnerText.Replace("\r", " ").Replace("\n", " ").Replace("\t", " ");
                WebApiHost = xml.SelectSingleNode("HE/WebApiHost").InnerText.Replace("\r", " ").Replace("\n", " ").Replace("\t", " ");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
