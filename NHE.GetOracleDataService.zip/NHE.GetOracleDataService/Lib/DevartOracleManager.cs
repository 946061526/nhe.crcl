﻿using Devart.Data.Oracle;
using System;
using System.Data;

namespace NHE.GetOracleDataService
{
    /// <summary>
    /// 数据库辅助类
    /// </summary>
    public class DevartOracleManager
    {

        /// <summary>
        /// 获取数据库连接
        /// </summary>
        /// <returns></returns>
        public static OracleConnection GetConn(string connStr)
        {
            OracleConnection conn = new OracleConnection(connStr);
            conn.Open();
            return conn;
        }

        /// <summary>
        /// 关闭连接
        /// </summary>
        /// <param name="conn"></param>
        public static void CloseConn(OracleConnection conn)
        {
            if (conn == null) { return; }
            try
            {
                if (conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                conn.Dispose();
            }
        }

        /// <summary>
        /// 查询结果集，返回DataTable
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="conn"></param>
        /// <returns></returns>
        public static DataTable GetDataTable(string sql, OracleConnection conn)
        {
            DataTable ds = new DataTable();
            OracleDataAdapter da = new OracleDataAdapter(sql, conn);
            da.Fill(ds);
            return ds;

        }

        /// <summary>
        /// 执行sql语句，返回受影响行数
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="conn"></param>
        /// <returns></returns>
        public static int ExecuteNonQuery(string sql, OracleConnection conn)
        {
            //创建操作命令对象 
            //OracleCommand cmd = new OracleCommand(sql, conn);
            OracleCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = sql;
            int val = cmd.ExecuteNonQuery();
            conn.Close();
            cmd.Dispose();
            return val;
        }

        /// <summary>
        /// 执行sql语句，返回受影响行数
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="conn"></param>
        /// <returns></returns>
        public static int Execute(string accno, OracleConnection conn)
        {
            //创建操作命令对象 
            OracleCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update risdb.PATREGISTER set print_status='已打印' where patno = :accno";
            cmd.Parameters.AddWithValue("accno", accno);
            int val = cmd.ExecuteNonQuery();

            //OracleCommand cmd = new OracleCommand(sql, conn);
            //int val = cmd.ExecuteNonQuery();
            //conn.Close();
            //cmd.Dispose();
            return val;
        }

        public static bool ExecTransfer(string sql, OracleConnection conn)
        {
            OracleTransaction tran = null;
            try
            {
                tran = conn.BeginTransaction();

                using (OracleCommand cmd = new OracleCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = sql;
                    cmd.Transaction = tran;
                    cmd.ExecuteNonQuery();
                }

                tran.Commit();
                return true;
            }
            catch (Exception ex)
            {
                tran.Rollback();
                throw new Exception(ex.Message);
            }
        }
    }
}
