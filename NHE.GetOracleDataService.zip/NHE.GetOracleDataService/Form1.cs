﻿

using Devart.Data.Oracle;
using System;
using System.Windows.Forms; 

namespace NHE.GetOracleDataService
{
    /************************************************
    *Author: Chen Xin KM.CII
    *Create Time ：2020.03.02 22:22
    *Description:
    *
    *Update History:
    *
    ***********************************************/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=192.168.8.168)(PORT=1521))(CONNECT_DATA=(SID=TS)));User Id=system;Password=Sin19900530;"; ;
        
            OracleConnection myConnection = new OracleConnection(connectionString);
            myConnection.Open();
           
            OracleCommand command = myConnection.CreateCommand();
            command.CommandText = "SELECT DNAME FROM SCOTT.\"DEPT\" WHERE DEPTNO=10";


            using (OracleDataReader reader = command.ExecuteReader())
            {
                // printing the column names
                for (int i = 0; i < reader.FieldCount; i++)
                    Console.Write(reader.GetName(i).ToString() + "\t");
                Console.Write(Environment.NewLine);
                // Always call Read before accesing data
                while (reader.Read())
                {
                    // printing the table content
                    for (int i = 0; i < reader.FieldCount; i++)
                        Console.Write(reader.GetValue(i).ToString() + "\t");
                    Console.Write(Environment.NewLine);
                }
            }
            myConnection.Close();
        }
    }
}
