﻿using Devart.Data.Oracle;
using NLog;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;

namespace NHE.GetOracleDataService
{
    public class Main
    {
        private Logger _logger = LogManager.GetCurrentClassLogger();

        private AppSetting _appSetting = null;
        private OracleConnection _oracleConnection = null;

        /// <summary>
        /// 启动
        /// </summary>
        public void Start()
        {
            _logger.Info("服务已启动");

            _appSetting = new AppSetting();

            var appstr = Newtonsoft.Json.JsonConvert.SerializeObject(_appSetting);
            _logger.Info($"解析到配置文件为：{appstr}");

            Thread t = new Thread(Do);
            t.Start();

            //注册WebHost
            new WebApiHelper().RegisterWebApiHost(_appSetting.WebApiHost);
        }

        /// <summary>
        /// 执行线程
        /// </summary>
        private void Do()
        {
            var interval = _appSetting.Interval * 1000;//毫秒
            var minutes = -_appSetting.DataStartTime;
            while (true)
            {
                try
                {
                    var sql = string.Format(_appSetting.Sql, minutes);

                    _logger.Info($"本次执行的sql语句为：{sql}");

                    var list = GetData(sql);
                    var i = 0;
                    if (list.Any())
                    {
                        //发送数据
                        list.ForEach(item =>
                        {
                            var send = SendData(item);
                            if (send) i += 1;
                        });
                    }
                    _logger.Info($"本次从oracle读取到数据条数：{list.Count}，往服务器发送成功条数：{i}。获取到的数据详情为：{Newtonsoft.Json.JsonConvert.SerializeObject(list)}");

                    Thread.Sleep(interval);
                }
                catch (Exception ex)
                {
                    _logger.Error($"服务运行出错：{ex.Message}");
                }
                finally
                {
                    GC.Collect();
                    Thread.Sleep(1000);
                }
            }
        }

        /// <summary>
        /// 获取数据
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        private List<PacsReportModel> GetData(string sql)
        {
            List<PacsReportModel> list = new List<PacsReportModel>();
            try
            {
                _oracleConnection = DevartOracleManager.GetConn(_appSetting.OracleConn);
                var cmd = _oracleConnection.CreateCommand(sql, CommandType.Text);
                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    PacsReportModel model = new PacsReportModel()
                    {
                        AccNo = reader["AccNo"].ToString(),
                        PatientID = reader["PatientID"].ToString(),
                        sName = reader["sName"].ToString(),
                        Age = reader["Age"].ToString(),
                        Sex = reader["Sex"].ToString(),
                        CheckPart = reader["CheckPart"].ToString(),
                        Depart = reader["Depart"].ToString(),
                        ZyNo = reader["ZyNo"].ToString(),
                        CheckMechine = reader["CheckMechine"].ToString(),

                        ReportDoc = reader["ReportDoc"].ToString(),
                        ComDoc = reader["ComDoc"].ToString(),
                        ComDoc1 = "",
                        ComDocImg = "",
                        DataType = 1,
                        ReportFile = reader["ReportFile"].ToString(),
                        IsPrint = reader["IsPrint"].ToString() == "1",

                        ZYType = reader["ZYType"].ToString(),
                        PaperNum = 0,
                        ImgNum = 0,
                        ReportWatch = reader["ReportWatch"].ToString(),
                        ReportContent = reader["ReportContent"].ToString(),

                        Remark1 = reader["BedNo"].ToString(),//床位号
                        Remark3 = reader["Diagnose"].ToString(),//临床诊断

                        FileType = 2,
                    };
                    DateTime CheckTime = new DateTime();
                    DateTime.TryParse(reader["CheckTime"].ToString(), out CheckTime);
                    model.CheckTime = CheckTime;
                    model.Remark2 = CheckTime.ToString("yyyy-MM-dd");//检查时间 yyyy-MM-dd

                    DateTime ReportTime = new DateTime();
                    DateTime.TryParse(reader["ReportTime"].ToString(), out ReportTime);
                    model.ReportTime = ReportTime;

                    list.Add(model);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"读取数据异常：{ex.Message}");
            }
            finally
            {
                DevartOracleManager.CloseConn(_oracleConnection);
            }
            return list;
        }

        /// <summary>
        /// 往服务端发送数据
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private bool SendData(PacsReportModel model)
        {
            if (model == null)
                return false;
            try
            {
                RestClient restClient = new RestClient(_appSetting.SaveUrl);
                var request = new RestRequest
                {
                    Method = Method.POST
                };
                request.AddJsonBody(model);
                var response = restClient.Execute(request);
                if (response.StatusCode == System.Net.HttpStatusCode.OK && response.Content == "OK")
                {
                    return true;
                }
                else
                {
                    var str = Newtonsoft.Json.JsonConvert.SerializeObject(model);
                    _logger.Warn($"数据发送失败：发送的数据为{str}，返回结果为：response.Content={response.Content}");
                    return false;
                }
            }
            catch (Exception ex)
            {
                var str = Newtonsoft.Json.JsonConvert.SerializeObject(model);
                _logger.Error($"数据发送失败：{ex.Message}，发送的数据为{str}");
                return false;
            }
        }

        /// <summary>
        /// 停止
        /// </summary>
        public void Stop()
        {
            _logger.Info("服务已停止");
        }
    }
}
