﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NHE.GetOracleDataService
{
	/// <summary>
	/// 定义从Pacs系统返回的数据模型
	/// </summary>
	public class PacsReportModel
	{
		/// <summary>
		/// AccNo 检查号
		/// </summary>
		public string AccNo { get; set; }

		/// <summary>
		/// PatientID 病人号
		/// </summary>
		public string PatientID { get; set; }

		/// <summary>
		/// sName 病人姓名
		/// </summary>
		public string sName { get; set; }

		/// <summary>
		/// Age 病人年龄
		/// </summary>
		public string Age { get; set; }

		/// <summary>
		/// Sex 病人性别
		/// </summary>
		public string Sex { get; set; }

		/// <summary>
		/// CheckPart 检查部位
		/// </summary> 
		public string CheckPart { get; set; } = "";

		/// <summary>
		/// Depart 申请科室
		/// </summary>
		public string Depart { get; set; } = "";

		/// <summary>
		/// ZyNo 住院号
		/// </summary>
		public string ZyNo { get; set; } = "";

		/// <summary>
		/// CheckMechine 检查设备 - ModalityType
		/// </summary>
		public string CheckMechine { get; set; } = "";

		/// <summary>
		/// CheckTime 检查时间/检查日期
		/// </summary>
		public DateTime CheckTime { get; set; } = new DateTime();

		/// <summary>
		/// ReportTime 报告时间/报告生成时间
		/// </summary>
		public DateTime ReportTime { get; set; } = new DateTime();

		/// <summary>
		/// ReportDoc 报告医生  
		/// </summary>
		public string ReportDoc { get; set; }

		/// <summary>
		/// ComDoc 审核医生 ArchivedDoc
		/// </summary>
		public string ComDoc { get; set; }

		/// <summary>
		/// ComDoc1    --该字段可为空，复审医生，如果为空，就以审核医生，不为空，审核医生为复审医生
		/// </summary>
		public string ComDoc1 { get; set; } = "";

		/// <summary> 
		/// ComDocImg   --该字段可为空，审核医生签名，如果为空则使用系统签名管理签名,不为空内容为：table|查询字段|条件字段
		/// </summary>
		public string ComDocImg { get; set; }

		/// <summary>
		/// DataType 数据类型(0-默认 只取报告信息判断是否住院(重庆中医院定制)  1-全文本 2-半文本)
		/// </summary>
		public int DataType { get; set; } = 0;

		/// <summary>
		/// ReportFile 报告文件
		/// </summary>
		public string ReportFile { get; set; } = "";

		/// <summary>
		/// 是否已打印
		/// </summary>
		public bool IsPrint { get; set; } = false;


		#region 全文本使用 

		/// <summary>
		/// ZYType   住院标志只能是门诊或者住院
		/// </summary>
		public string ZYType { get; set; }

		/// <summary>
		/// 纸张数量
		/// </summary>
		public int PaperNum { get; set; } = 0;

		/// <summary>
		/// ImgNum 图片数量默认为 0
		/// </summary>
		public int ImgNum { get; set; } = 0;

		/// <summary>
		/// ReportWatch    检查所见
		/// </summary>
		public string ReportWatch { get; set; }

		/// <summary>
		/// ReportContent   报告内容
		/// </summary>
		public string ReportContent { get; set; }

		#endregion

		#region 半文本使用 

		/// <summary>
		/// FileType 文件形式（1代表FTP，2代表其他）
		/// </summary>
		public int FileType { get; set; } = 2;

		#endregion

		#region 扩展字段

		/// <summary>
		/// 备用字段 1
		/// </summary>
		public string Remark1 { get; set; }

		/// <summary>
		/// 备用字段 2
		/// </summary>
		public string Remark2 { get; set; }

		/// <summary>
		/// 备用字段 3
		/// </summary>
		public string Remark3 { get; set; }

		/// <summary>
		/// 备用字段 4
		/// </summary>
		public string Remark4 { get; set; }

		/// <summary>
		/// 备用字段 5
		/// </summary>
		public string Remark5 { get; set; }

		/// <summary>
		/// 备用字段 6
		/// </summary>
		public string Remark6 { get; set; }

		/// <summary>
		/// 备用字段 7
		/// </summary>
		public string Remark7 { get; set; }

		/// <summary>
		/// 备用字段 8
		/// </summary>
		public string Remark8 { get; set; }

		/// <summary>
		/// 备用字段 9
		/// </summary>
		public string Remark9 { get; set; }

		/// <summary>
		/// 备用字段 10
		/// </summary>
		public string Remark10 { get; set; }

		#endregion
	}
}

