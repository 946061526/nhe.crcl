﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NHE.GetOracleDataService.Model
{
    /// <summary>
    /// 回传打印状态模型
    /// </summary>
    public class NotifyPrintStatusModel : CheckModel
    {
        /// <summary>
        /// 胶片是否已经被取走  0-未取走 1-已取走 
        /// </summary>
        public int FilmOut { get; set; }

        /// <summary>
        /// 胶片打印状态 0-未打印 1-已打印 2-打印中
        /// </summary>
        public int FilmPrintStatus { get; set; }

        /// <summary>
        /// 报告是否已经被取走  0-未取走 1-已取走 
        /// </summary>
        public int ReportOut { get; set; }

        /// <summary>
        /// 报告打印状态 0-未打印 1-已打印 2-打印中
        /// </summary>
        public int ReportPrintStatus { get; set; }
    }

    /// <summary>
	/// 检查模型
	/// </summary>
	public class CheckModel
    {
        /// <summary>
        /// AccNo 检查号
        /// </summary>
        public string AccNo { get; set; }

        /// <summary>
        /// PatientID 病人号
        /// </summary>
        public string PatientID { get; set; }

        /// <summary>
        /// Offset 取最近多少时间的数据 单位:分钟
        /// </summary>
        public int Offset { get; set; } = 10080;

    }
}
