﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NHE.GetOracleDataService
{
    public class ReportModel
    {
        public int ID { get; set; } = 0;
        /// <summary>
        /// 来源设备
        /// </summary>
        public string ReportIdentity { get; set; }
        /// <summary>
        /// 检查号
        /// </summary>
        public string AccNo { get; set; }
        /// <summary>
        /// 病人ID
        /// </summary>
        public string PatientID { get; set; }
        /// <summary>
        /// 姓名
        /// </summary>
        public string sName { get; set; }
        /// <summary>
        /// 年龄
        /// </summary>
        public string Age { get; set; }
        /// <summary>
        /// 性别
        /// </summary>
        public string Sex { get; set; }
        /// <summary>
        /// 检查部位
        /// </summary>
        public string CheckPar { get; set; }
        /// <summary>
        /// 申请科室
        /// </summary>
        public string Depart { get; set; }
        /// <summary>
        /// 是否为住院
        /// </summary>
        public int IsZY { get; set; }

        /// <summary>
        /// ZyNo 住院号
        /// </summary>
        public string ZyNo { get; set; } = "";
        /// <summary>
        /// 检查设备
        /// </summary>
        public string CheckMechine { get; set; }
        /// <summary>
        /// 检查时间
        /// </summary>
        public DateTime CheckTime { get; set; }
        /// <summary>
        /// 报告医生
        /// </summary>
        public string ReportDoc { get; set; }
        /// <summary>
        /// 审核医生
        /// </summary>
        public string ComDoc { get; set; }
        /// <summary>
        /// 报告文件
        /// </summary>
        public string ReportFile { get; set; }
        /// <summary>
        /// 接收时间
        /// </summary>
        public DateTime ReciveTime { get; set; }
        /// <summary>
        /// 是否打印
        /// </summary>
        public int IsPrint { get; set; }
        /// <summary>
        /// 打印类型
        /// </summary>
        public int PrintType { get; set; }
        /// <summary>
        /// 是否为特殊病人
        /// </summary>
        public int IsSpecial { get; set; }
        /// <summary>
        /// 纸张数量
        /// </summary>
        public int PaperNum { get; set; }
        /// <summary>
        /// 病人类型
        /// </summary>
        public string PatientType { get; set; }

        /// <summary>
        /// ReportWatch    检查所见
        /// </summary>
        public string ReportWatch { get; set; }

        /// <summary>
        /// ReportContent   报告内容
        /// </summary>
        public string ReportContent { get; set; }
    }
}
