﻿//using Devart.Data.Oracle;
using NHE.GetOracleDataService.Model;
using NLog;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Http;

namespace NHE.GetOracleDataService.Controller
{
    [RoutePrefix("api/interface")]
    public class InterfaceController : ApiController
    {
        private Logger _logger = LogManager.GetCurrentClassLogger();
        private AppSetting _appSetting = null;
        private Oracle.ManagedDataAccess.Client.OracleConnection _oracleConnection = null;
        private Devart.Data.Oracle.OracleConnection _oracleConnection_Devart = null;

        public InterfaceController()
        {
            _appSetting = new AppSetting();
        }

        [HttpGet]
        [Route("Test")]
        public string Test(string id)
        {
            try
            {
                string result = "";
                if (id == "db0")
                {
                    _oracleConnection = NetOracleManager.GetConn(_appSetting.OracleConnUpdateStatus);
                    var cmd = new Oracle.ManagedDataAccess.Client.OracleCommand("select print_status from risdb.patregister where clinicno='6558340'", _oracleConnection);
                    var reader = cmd.ExecuteReader();

                    result += $"\n OracleConnUpdateStatus={_appSetting.OracleConnUpdateStatus}";
                    while (reader.Read())
                    {
                        result += $"\n print_status={reader["print_status"]}";
                    }
                }
                else if (id == "db1")
                {
                    _oracleConnection_Devart = DevartOracleManager.GetConn(_appSetting.OracleConnUpdateStatus);
                    var cmd = new Devart.Data.Oracle.OracleCommand("select print_status from risdb.patregister where clinicno='6558340'", _oracleConnection_Devart);
                    var reader = cmd.ExecuteReader();

                    result += $"\n OracleConnUpdateStatus={_appSetting.OracleConnUpdateStatus}";
                    while (reader.Read())
                    {
                        result += $"\n print_status={reader["print_status"]}";
                    }
                }
                else if (id == "db2")
                {
                    _oracleConnection_Devart = DevartOracleManager.GetConn(_appSetting.OracleConn);
                    var cmd = new Devart.Data.Oracle.OracleCommand(_appSetting.Sql, _oracleConnection_Devart);
                    var reader = cmd.ExecuteReader();

                    result += $"\n OracleConn={_appSetting.OracleConn}";
                    while (reader.Read())
                    {
                        var AccNo = reader["AccNo"].ToString();
                        var PatientID = reader["PatientID"].ToString();
                        var sName = reader["sName"].ToString();
                        var Age = reader["Age"].ToString();

                        result += $"\n AccNo={AccNo},PatientID={PatientID},sName={sName},Age={Age}";
                    }
                }
                else if (id == "168")
                {
                    string sql = $"update scott.dept set dname='测试---{id}' where DEPTNO=10";
                    string connectionString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=192.168.8.168)(PORT=1521))(CONNECT_DATA=(SID=TS)));User Id=system;Password=Sin19900530;";
                    _oracleConnection_Devart = DevartOracleManager.GetConn(connectionString);
                    //var i = DevartOracleManager.ExecuteNonQuery(sql, _oracleConnection_Devart);

                    //result = $"成功:{ i.ToString()}";


                    var cmd = new Devart.Data.Oracle.OracleCommand(sql, _oracleConnection_Devart);
                    var reader = cmd.ExecuteReader();
                    //var patno = "";
                    //while (reader.Read())
                    //{
                    //    patno = reader["patno"].ToString();
                    //    break;
                    //}
                    result = "read ok";
                }
                else
                {
                    result = $"ok-{id}";
                }

                return result;
            }
            catch (Exception ex)
            {
                return "failed :" + ex.Message;
            }

            //string sql = $"update scott.dept set dname='测试{id}' where DEPTNO=10";
            //string connectionString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=192.168.8.168)(PORT=1521))(CONNECT_DATA=(SID=TS)));User Id=system;Password=Sin19900530;";
            //_oracleConnection = SqlHelper.GetConn(connectionString);
            //var result = SqlHelper.ExecuteNonQuery(sql, _oracleConnection);

            //_logger.Info($"\r\t\n回写打印状态(TestOracle)，执行请求：id={id}，sql={sql}，返回受影响行数：{result}");

            //GetData();

            //return "success";
        }

        /// <summary>
        /// 回写打印状态
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("WriteBackPrintStatus")]
        public bool WriteBackPrintStatus(NotifyPrintStatusModel model)
        {
            _logger.Info($"\n开始回写状态，AccNo={model?.AccNo}");
            if (string.IsNullOrEmpty(model?.AccNo) || (model.ReportPrintStatus != 1 && model.FilmPrintStatus != 1))
            {
                _logger.Info($"\n回写打印状态参数有误：AccNo={model?.AccNo} & ReportPrintStatus={model.ReportPrintStatus} & FilmPrintStatus={model.FilmPrintStatus}");
                return false;
            }
            try
            {
                #region 测试
                /* 测试
                if (model.ReportPrintStatus == 1)
                {
                    //string sql = $"update patregister set print_status='已打印' where clinicno='{model.AccNo}'";
                    string sql = string.Format(_appSetting.SqlUpdateStatus, model.AccNo);

                    _oracleConnection_Devart = DevartOracleManager.GetConn(_appSetting.OracleConnUpdateStatus);
                    _logger.Info($"\n回写打印状态，数据库连接成功，连接状态：{_oracleConnection_Devart.State}，执行sql={sql}");

                    #region 先查询

                    //先查询
                    //var cmd = new Devart.Data.Oracle.OracleCommand("select patno,print_status from risdb.PATREGISTER where clinicno='6558340'", _oracleConnection_Devart);
                    //var reader = cmd.ExecuteReader();
                    //var patno = "";
                    //while (reader.Read())
                    //{
                    //    patno = reader["patno"].ToString();
                    //    break;
                    //}

                    //_logger.Info($"\n回写打印状态，数据库连接成功，连接状态：{_oracleConnection_Devart.State，查询到主键patno={patno}");

                    //sql = $"update risdb.PATREGISTER set print_status='0' where patno='{patno}'";

                    //_logger.Info($"\n回写打印状态，根据查询到的主键修改状态，执行sql：{sql}");

                    #endregion

                    //var result = DevartOracleManager.Execute(patno, _oracleConnection_Devart);
                    var result = DevartOracleManager.ExecuteNonQuery(sql, _oracleConnection_Devart);

                    _logger.Info($"\n回写打印状态，执行sql={sql}，返回受影响行数：{result}");

                    return result > 0;

                    ////执行事务
                    //_logger.Info($"\n回写打印状态，开始执行事务");

                    //var res = DevartOracleManager.ExecTransfer(sql, _oracleConnection_Devart);
                    //_logger.Info($"\n回写打印状态，开始执行事务，执行sql={sql}，执行结果：{res}");
                    //return res;

                    //_logger.Info($"\n回写打印状态，开始执行Reader");
                    //var cmd = new Devart.Data.Oracle.OracleCommand(sql, _oracleConnection_Devart);
                    //var reader = cmd.ExecuteReader();

                    //_logger.Info($"\n回写打印状态执行成功");

                    //return true;
                }
                else
                {
                    //string sql = $"update patregister set print_status='已打印' where clinicno='{model.AccNo}'";
                    string sql = string.Format(_appSetting.SqlUpdateStatus, model.AccNo);

                    //_logger.Info($"\n回写打印状态，执行sql={sql}，连接串：{_appSetting.OracleConnUpdateStatus}");

                    _oracleConnection = NetOracleManager.GetConn(_appSetting.OracleConnUpdateStatus);

                    _logger.Info($"\n回写打印状态，已成功建立连接，sql={sql}");

                    var result = NetOracleManager.ExecuteNonQuery(sql, _oracleConnection);

                    _logger.Info($"\n回写打印状态，执行sql={sql}，返回受影响行数：{result}");

                    return result > 0;
                }
                */
                #endregion

                //string sql = $"update patregister set print_status='已打印' where clinicno='{model.AccNo}'";
                string sql = string.Format(_appSetting.SqlUpdateStatus, model.AccNo);

                _oracleConnection_Devart = DevartOracleManager.GetConn(_appSetting.OracleConnUpdateStatus);
                _logger.Info($"\n回写打印状态，数据库连接成功，连接状态：{_oracleConnection_Devart.State}，执行sql={sql}");

                var result = DevartOracleManager.ExecuteNonQuery(sql, _oracleConnection_Devart);

                _logger.Info($"\n回写打印状态，返回受影响行数：{result}");

                return result > 0;
            }
            catch (Exception ex)
            {
                _logger.Error($"\n回写打印状态异常：{ex.Message}");
                return false;
            }
            finally
            {
                //NetOracleManager.CloseConn(_oracleConnection);
                DevartOracleManager.CloseConn(_oracleConnection_Devart);
            }
        }


        ///// <summary>
        ///// 获取数据
        ///// </summary>
        ///// <param name="time"></param>
        ///// <returns></returns>
        //private List<PacsReportModel> GetData()
        //{
        //    List<PacsReportModel> list = new List<PacsReportModel>();
        //    try
        //    {
        //        _oracleConnection = NetOracleManager.GetConn(_appSetting.OracleConn);
        //        //var cmd = _oracleConnection.CreateCommand("select * from scott.dept", CommandType.Text);
        //        var cmd = new Oracle.ManagedDataAccess.Client.OracleCommand("select * from scott.dept", _oracleConnection);
        //        var reader = cmd.ExecuteReader();

        //        while (reader.Read())
        //        {
        //            _logger.Info($"No={reader["DEPTNO"]}，dname={reader["dname"]}");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.Error($"读取数据异常：{ex.Message}");
        //    }
        //    finally
        //    {
        //        NetOracleManager.CloseConn(_oracleConnection);
        //    }
        //    return list;
        //}


    }
}
